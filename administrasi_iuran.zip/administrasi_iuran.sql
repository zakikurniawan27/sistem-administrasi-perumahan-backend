-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 21 Jul 2024 pada 21.28
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `administrasi_iuran`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bulans`
--

CREATE TABLE `bulans` (
  `id` int(11) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `status_pembayaran` varchar(255) NOT NULL DEFAULT 'BELUM LUNAS',
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `bulans`
--

INSERT INTO `bulans` (`id`, `nama`, `status_pembayaran`, `createdAt`, `updatedAt`) VALUES
(1, 'Januari', 'SUDAH LUNAS', '2024-07-21 18:28:22', '2024-07-21 18:33:01'),
(2, 'Februari', 'SUDAH LUNAS', '2024-07-21 18:28:30', '2024-07-21 18:33:14'),
(3, 'Maret', 'SUDAH LUNAS', '2024-07-21 18:28:38', '2024-07-21 18:33:23'),
(4, 'April', 'SUDAH LUNAS', '2024-07-21 18:28:49', '2024-07-21 18:32:31'),
(5, 'Mei', 'SUDAH LUNAS', '2024-07-21 18:28:56', '2024-07-21 18:31:11'),
(6, 'Juni', 'SUDAH LUNAS', '2024-07-21 18:29:04', '2024-07-21 18:31:36'),
(7, 'Juli', 'BELUM LUNAS', '2024-07-21 18:29:09', '2024-07-21 18:29:09'),
(8, 'Agustus', 'BELUM LUNAS', '2024-07-21 18:29:17', '2024-07-21 18:29:17'),
(9, 'September', 'BELUM LUNAS', '2024-07-21 18:29:30', '2024-07-21 18:29:30'),
(10, 'Oktober', 'BELUM LUNAS', '2024-07-21 18:29:38', '2024-07-21 18:29:38'),
(11, 'November', 'BELUM LUNAS', '2024-07-21 18:29:46', '2024-07-21 18:29:46'),
(12, 'Desember', 'BELUM LUNAS', '2024-07-21 18:29:54', '2024-07-21 18:29:54');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembayarans`
--

CREATE TABLE `pembayarans` (
  `id` int(11) NOT NULL,
  `penghuniId` int(11) NOT NULL,
  `bulanId` int(11) NOT NULL,
  `saldo_masuk` varchar(255) DEFAULT NULL,
  `jenis_iuran` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pembayarans`
--

INSERT INTO `pembayarans` (`id`, `penghuniId`, `bulanId`, `saldo_masuk`, `jenis_iuran`, `createdAt`, `updatedAt`) VALUES
(1, 1, 1, '100000', 'Satpam', '2024-07-21 18:30:20', '2024-07-21 18:30:20'),
(2, 1, 2, '100000', 'Satpam', '2024-07-21 18:30:31', '2024-07-21 18:30:31'),
(3, 1, 3, '100000', 'Satpam', '2024-07-21 18:30:47', '2024-07-21 18:30:47'),
(4, 1, 4, '100000', 'Satpam', '2024-07-21 18:30:59', '2024-07-21 18:30:59'),
(5, 1, 5, '100000', 'Satpam', '2024-07-21 18:31:11', '2024-07-21 18:31:11'),
(6, 1, 6, '100000', 'Satpam', '2024-07-21 18:31:36', '2024-07-21 18:31:36'),
(7, 2, 1, '100000', 'Satpam', '2024-07-21 18:31:49', '2024-07-21 18:31:49'),
(8, 2, 2, '100000', 'Satpam', '2024-07-21 18:32:02', '2024-07-21 18:32:02'),
(9, 2, 3, '100000', 'Satpam', '2024-07-21 18:32:12', '2024-07-21 18:32:12'),
(10, 2, 4, '100000', 'Satpam', '2024-07-21 18:32:31', '2024-07-21 18:32:31'),
(11, 1, 1, '15000', 'Kebersihan', '2024-07-21 18:32:50', '2024-07-21 18:32:50'),
(12, 2, 1, '15000', 'Kebersihan', '2024-07-21 18:33:01', '2024-07-21 18:33:01'),
(13, 1, 2, '15000', 'Kebersihan', '2024-07-21 18:33:14', '2024-07-21 18:33:14'),
(14, 1, 3, '15000', 'Kebersihan', '2024-07-21 18:33:23', '2024-07-21 18:33:23');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengeluarans`
--

CREATE TABLE `pengeluarans` (
  `id` int(11) NOT NULL,
  `bulanId` int(11) NOT NULL,
  `jenis_pengeluaran` varchar(255) NOT NULL,
  `saldo_keluar` varchar(255) DEFAULT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Struktur dari tabel `penghunis`
--

CREATE TABLE `penghunis` (
  `id` int(11) NOT NULL,
  `nama_lengkap` varchar(255) NOT NULL,
  `foto_ktp` varchar(255) NOT NULL,
  `status_hunian` varchar(255) NOT NULL,
  `nomor_telepon` varchar(255) NOT NULL,
  `status_pernikahan` varchar(255) NOT NULL,
  `rumahId` int(11) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `penghunis`
--

INSERT INTO `penghunis` (`id`, `nama_lengkap`, `foto_ktp`, `status_hunian`, `nomor_telepon`, `status_pernikahan`, `rumahId`, `createdAt`, `updatedAt`) VALUES
(1, 'Muhammad Zaki Kurniawan', 'D:\\My Project\\test-beon-intermedia\\backend\\administrasi-iuran-perumahan\\src\\middlewares\\uploads\\1721586325568-Foto - Muhammad Zaki Kurniawan.jpg', 'Tetap', '019218821121', 'Belum Menikah', 1, '2024-07-21 18:25:25', '2024-07-21 18:25:25'),
(2, 'samsul', 'D:\\My Project\\test-beon-intermedia\\backend\\administrasi-iuran-perumahan\\src\\middlewares\\uploads\\1721586382446-Foto - Muhammad Zaki Kurniawan.jpg', 'Tetap', '0918232191', 'Sudah Menikah', 2, '2024-07-21 18:26:22', '2024-07-21 18:26:22'),
(3, 'ibrahim', 'D:\\My Project\\test-beon-intermedia\\backend\\administrasi-iuran-perumahan\\src\\middlewares\\uploads\\1721586409473-Foto - Muhammad Zaki Kurniawan.jpg', 'Tetap', '192111231100', 'Belum Menikah', 3, '2024-07-21 18:26:49', '2024-07-21 18:26:49'),
(4, 'messi', 'D:\\My Project\\test-beon-intermedia\\backend\\administrasi-iuran-perumahan\\src\\middlewares\\uploads\\1721586436009-Foto - Muhammad Zaki Kurniawan.jpg', 'Tetap', '0918232191', 'Sudah Menikah', 4, '2024-07-21 18:27:16', '2024-07-21 18:27:16'),
(5, 'ronaldo', 'D:\\My Project\\test-beon-intermedia\\backend\\administrasi-iuran-perumahan\\src\\middlewares\\uploads\\1721586461706-Foto - Muhammad Zaki Kurniawan.jpg', 'Tetap', '192188221222', 'Belum Menikah', 5, '2024-07-21 18:27:41', '2024-07-21 18:27:41');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rumahs`
--

CREATE TABLE `rumahs` (
  `id` int(11) NOT NULL,
  `nomor_rumah` varchar(255) NOT NULL,
  `status_hunian` varchar(255) NOT NULL DEFAULT 'TIDAK DIHUNI',
  `blok_rumah` varchar(255) NOT NULL,
  `createdAt` datetime NOT NULL,
  `updatedAt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `rumahs`
--

INSERT INTO `rumahs` (`id`, `nomor_rumah`, `status_hunian`, `blok_rumah`, `createdAt`, `updatedAt`) VALUES
(1, '1', 'DIHUNI', 'A', '2024-07-21 18:10:14', '2024-07-21 18:25:25'),
(2, '2', 'DIHUNI', 'A', '2024-07-21 18:10:25', '2024-07-21 18:26:22'),
(3, '3', 'DIHUNI', 'A', '2024-07-21 18:10:34', '2024-07-21 18:26:49'),
(4, '4', 'DIHUNI', 'A', '2024-07-21 18:10:43', '2024-07-21 18:27:16'),
(5, '5', 'DIHUNI', 'A', '2024-07-21 18:10:53', '2024-07-21 18:27:41'),
(6, '6', 'TIDAK DIHUNI', 'B', '2024-07-21 18:11:17', '2024-07-21 18:11:17'),
(7, '7', 'TIDAK DIHUNI', 'B', '2024-07-21 18:11:28', '2024-07-21 18:11:28'),
(8, '8', 'TIDAK DIHUNI', 'B', '2024-07-21 18:11:39', '2024-07-21 18:11:39'),
(9, '9', 'TIDAK DIHUNI', 'B', '2024-07-21 18:11:50', '2024-07-21 18:11:50'),
(10, '10', 'TIDAK DIHUNI', 'B', '2024-07-21 18:12:03', '2024-07-21 18:12:03'),
(11, '11', 'TIDAK DIHUNI', 'C', '2024-07-21 18:12:14', '2024-07-21 18:12:14'),
(12, '12', 'TIDAK DIHUNI', 'C', '2024-07-21 18:12:24', '2024-07-21 18:12:24'),
(13, '13', 'TIDAK DIHUNI', 'C', '2024-07-21 18:12:35', '2024-07-21 18:12:35'),
(14, '14', 'TIDAK DIHUNI', 'C', '2024-07-21 18:12:50', '2024-07-21 18:12:50'),
(15, '15', 'TIDAK DIHUNI', 'C', '2024-07-21 18:13:09', '2024-07-21 18:13:09'),
(16, '16', 'TIDAK DIHUNI', 'D', '2024-07-21 18:13:20', '2024-07-21 18:13:20'),
(17, '17', 'TIDAK DIHUNI', 'D', '2024-07-21 18:13:37', '2024-07-21 18:13:37'),
(18, '18', 'TIDAK DIHUNI', 'D', '2024-07-21 18:13:50', '2024-07-21 18:13:50'),
(19, '19', 'TIDAK DIHUNI', 'D', '2024-07-21 18:14:02', '2024-07-21 18:14:02'),
(20, '20', 'TIDAK DIHUNI', 'D', '2024-07-21 18:14:16', '2024-07-21 18:14:16');

-- --------------------------------------------------------

--
-- Struktur dari tabel `sequelizemeta`
--

CREATE TABLE `sequelizemeta` (
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data untuk tabel `sequelizemeta`
--

INSERT INTO `sequelizemeta` (`name`) VALUES
('1-create-rumah.js'),
('2-create-penghuni.js'),
('3-create-bulan.js'),
('4-create-pembayaran.js'),
('5-create-pengeluaran.js');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `bulans`
--
ALTER TABLE `bulans`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pembayarans`
--
ALTER TABLE `pembayarans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `penghuniId` (`penghuniId`),
  ADD KEY `bulanId` (`bulanId`);

--
-- Indeks untuk tabel `pengeluarans`
--
ALTER TABLE `pengeluarans`
  ADD PRIMARY KEY (`id`),
  ADD KEY `bulanId` (`bulanId`);

--
-- Indeks untuk tabel `penghunis`
--
ALTER TABLE `penghunis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `rumahId` (`rumahId`);

--
-- Indeks untuk tabel `rumahs`
--
ALTER TABLE `rumahs`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `sequelizemeta`
--
ALTER TABLE `sequelizemeta`
  ADD PRIMARY KEY (`name`),
  ADD UNIQUE KEY `name` (`name`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `bulans`
--
ALTER TABLE `bulans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `pembayarans`
--
ALTER TABLE `pembayarans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT untuk tabel `pengeluarans`
--
ALTER TABLE `pengeluarans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `penghunis`
--
ALTER TABLE `penghunis`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `rumahs`
--
ALTER TABLE `rumahs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pembayarans`
--
ALTER TABLE `pembayarans`
  ADD CONSTRAINT `pembayarans_ibfk_1` FOREIGN KEY (`penghuniId`) REFERENCES `penghunis` (`id`),
  ADD CONSTRAINT `pembayarans_ibfk_2` FOREIGN KEY (`bulanId`) REFERENCES `bulans` (`id`);

--
-- Ketidakleluasaan untuk tabel `pengeluarans`
--
ALTER TABLE `pengeluarans`
  ADD CONSTRAINT `pengeluarans_ibfk_1` FOREIGN KEY (`bulanId`) REFERENCES `bulans` (`id`);

--
-- Ketidakleluasaan untuk tabel `penghunis`
--
ALTER TABLE `penghunis`
  ADD CONSTRAINT `penghunis_ibfk_1` FOREIGN KEY (`rumahId`) REFERENCES `rumahs` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
